using Master_Details_01.Models;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace Master_Details_01.Controllers
{
    public class HomeController : Controller
    {
        private readonly CandidateDbContext _context;
        public HomeController(CandidateDbContext _context)
        {
            this._context = _context;
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Aggrigate()
        {
            int TotalMarks = _context.Results.Where(x=>x.CandidateId == 2).Count();
            ViewBag.totalMarks = TotalMarks;

            int Total = _context.Results.Where(x => x.CandidateId == 1).Sum(x=>x.Mark);
            ViewBag.total = Total;

            int max = _context.Results.Where(x => x.CandidateId == 1).Max(x => x.Mark);
            ViewBag.max = max;

            int min = _context.Results.Where(x => x.CandidateId == 1).Min(x => x.Mark);
            ViewBag.min = min;

            int avg = (int)_context.Results.Where(x => x.CandidateId == 1).Average(x => x.Mark);
            ViewBag.avg = avg;
            return View();
        }
    }
}
