﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Master_Details_01.Models
{
    public class Result
    {
        public int Id { get; set; }
        public int Mark { get; set; }
        [ForeignKey("Skill")]
        public int SkillId { get; set; }
        [ForeignKey("Candidate")]
        public int CandidateId { get; set; }

        //nav
        public virtual Skill? Skill { get; set; }
        public Candidate? Candidate { get; set; }
    }
}
