﻿using System.ComponentModel.DataAnnotations;

namespace Master_Details_01.Models.ViewModels
{
    public class CandidateVM
    {
        public int CandidateId { get; set; }
        [Required, StringLength(50)]
        public string CandidateName { get; set; } = default!;
        public DateTime DateOfBirth { get; set; }
        public string Phone { get; set; } = default!;
        public string? Image { get; set; }
        public IFormFile? ImagePath { get; set; }
        public bool Fresher { get; set; }

        public List<int> SkillList { get; set; } = new List<int>();
    }
}
