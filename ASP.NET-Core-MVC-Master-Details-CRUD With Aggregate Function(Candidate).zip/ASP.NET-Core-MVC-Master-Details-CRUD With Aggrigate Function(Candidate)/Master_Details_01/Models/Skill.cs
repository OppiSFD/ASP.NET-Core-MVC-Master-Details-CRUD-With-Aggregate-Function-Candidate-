﻿namespace Master_Details_01.Models
{
    public class Skill
    {
        public int SkillId { get; set; }
        public string SkillName { get; set; } = default!;

        public ICollection<CandidateSkill> CandidateSkills { get; set; } = new List<CandidateSkill>();
        public ICollection<Result> Results { get; set; } = new List<Result>();
    }
}
