﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Master_Details_01.Models
{
    public class CandidateSkill
    {
        public int CandidateSkillId { get; set; }
        [ForeignKey("Skill")]
        public int SkillId { get; set; }
        [ForeignKey("Candidate")]
        public int CandidateId { get; set; }

        //nav
        public virtual Skill? Skill { get; set; }
        public Candidate? Candidate { get; set; }
    }
}
