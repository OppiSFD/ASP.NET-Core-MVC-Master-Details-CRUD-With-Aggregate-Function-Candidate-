﻿using Microsoft.EntityFrameworkCore;

namespace Master_Details_01.Models
{
    public class CandidateDbContext : DbContext
    {
        public CandidateDbContext(DbContextOptions<CandidateDbContext> options): base(options)
        {
            
        }
        public DbSet<Candidate> Candidates { get; set; }
        public DbSet<Skill> Skills { get; set; }
        public DbSet<CandidateSkill> CandidateSkills { get; set; }
        public DbSet<Result> Results { get; set; }
    }
}
